# DAR SADIK — Application Professionnelle
## Next.js + Supabase + Vercel

---

## ETAPE 1 — Supabase (base de données)

1. Allez sur https://supabase.com → connectez-vous avec GitHub
2. Ouvrez votre projet "darsadik"
3. Menu gauche → SQL Editor
4. Ouvrez le fichier "supabase_setup.sql"
5. Copiez tout le contenu → collez → cliquez Run
6. Vous verrez "Success" ✅

---

## ETAPE 2 — GitHub (uploader le code)

1. Allez sur https://github.com/darsadik/darsadik
2. Supprimez le fichier "index.html.html" existant
3. Cliquez "Add file" → "Upload files"
4. Uploadez TOUT le contenu du dossier "darsadik-next"
   (package.json, pages/, components/, lib/, styles/, etc.)
5. Cliquez "Commit changes"

---

## ETAPE 3 — Vercel (mettre en ligne)

1. Allez sur https://vercel.com
2. Cliquez "Sign up" → connectez avec GitHub
3. Cliquez "New Project"
4. Sélectionnez votre repo "darsadik"
5. Dans "Environment Variables", ajoutez :
   - NEXT_PUBLIC_SUPABASE_URL = https://nqugvwurehltexqmaino.supabase.co
   - NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
6. Cliquez "Deploy"
7. Attendez 2 minutes → votre app est en ligne !

---

## ETAPE 4 — Ajouter vos données

1. Ouvrez votre app sur Vercel (ex: darsadik.vercel.app)
2. Créez votre compte (inscription)
3. Allez dans Paramètres → ajoutez :
   - Vos fournisseurs (NOVA BRIQ SARL, DURA BRIQ, SALIMO BRIQ)
   - Vos types de briques (B12, B10, B7GF1...)
   - Vos camions
4. Allez dans Clients → ajoutez vos 16 clients

OU utilisez le SQL commenté dans supabase_setup.sql
(remplacez VOTRE-UUID par votre vrai UUID)

---

## STRUCTURE DU PROJET

darsadik-next/
├── pages/
│   ├── _app.js          (authentification)
│   ├── index.js         (dashboard)
│   ├── ventes/          (saisie + historique)
│   ├── clients/         (liste + détail par client)
│   ├── paiements/       (paiements clients)
│   ├── gasoil/          (consommation carburant)
│   └── parametres/      (camions, fournisseurs, briques)
├── components/
│   └── Layout.js        (sidebar + topbar)
├── lib/
│   └── supabase.js      (connexion base de données)
├── styles/
│   └── globals.css      (design)
└── supabase_setup.sql   (création des tables)

---

## FONCTIONNALITES

✅ Authentification sécurisée
✅ Dashboard avec KPIs + stats par fournisseur + par camion
✅ Ventes : saisie complète + historique filtrable
✅ Clients : liste + fiche détaillée par client (ventes + paiements)
✅ Paiements : saisie + soustraction automatique du solde
✅ Gasoil : consommation par camion + KM
✅ Paramètres : ajout/suppression camions, fournisseurs, types briques
✅ Données en temps réel via Supabase
✅ Accès PC + téléphone via Vercel
✅ 100% gratuit

-- ============================================================
-- DAR SADIK — SQL COMPLET SUPABASE
-- Copiez tout ce code dans : Supabase → SQL Editor → Run
-- ============================================================

-- TABLE CLIENTS
CREATE TABLE IF NOT EXISTS clients (
  id BIGSERIAL PRIMARY KEY,
  nom TEXT NOT NULL,
  depot TEXT DEFAULT '',
  tel TEXT DEFAULT '',
  solde NUMERIC DEFAULT 0,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE CAMIONS
CREATE TABLE IF NOT EXISTS camions (
  id BIGSERIAL PRIMARY KEY,
  plaque TEXT NOT NULL,
  chauffeur TEXT DEFAULT '',
  depot TEXT DEFAULT '',
  gasoil_dhs NUMERIC DEFAULT 0,
  pleins INTEGER DEFAULT 0,
  litres NUMERIC DEFAULT 0,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE FOURNISSEURS
CREATE TABLE IF NOT EXISTS fournisseurs (
  id BIGSERIAL PRIMARY KEY,
  nom TEXT NOT NULL,
  tel TEXT DEFAULT '',
  note TEXT DEFAULT '',
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE TYPE BRIQUES
CREATE TABLE IF NOT EXISTS type_briques (
  id BIGSERIAL PRIMARY KEY,
  nom TEXT NOT NULL,
  description TEXT DEFAULT '',
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE VENTES
CREATE TABLE IF NOT EXISTS ventes (
  id BIGSERIAL PRIMARY KEY,
  date TEXT NOT NULL,
  client_id BIGINT REFERENCES clients(id) ON DELETE SET NULL,
  client_nom TEXT DEFAULT '',
  camion_id BIGINT REFERENCES camions(id) ON DELETE SET NULL,
  camion_plaque TEXT DEFAULT '',
  chauffeur TEXT DEFAULT '',
  fournisseur_id BIGINT REFERENCES fournisseurs(id) ON DELETE SET NULL,
  fournisseur TEXT DEFAULT '',
  type_brique_id BIGINT REFERENCES type_briques(id) ON DELETE SET NULL,
  type_brique TEXT DEFAULT '',
  qte NUMERIC DEFAULT 0,
  prix_vente NUMERIC DEFAULT 0,
  prix_achat NUMERIC DEFAULT 0,
  total_vente NUMERIC DEFAULT 0,
  total_achat NUMERIC DEFAULT 0,
  marge NUMERIC DEFAULT 0,
  bon TEXT DEFAULT '',
  note TEXT DEFAULT '',
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE GASOIL
CREATE TABLE IF NOT EXISTS gasoil (
  id BIGSERIAL PRIMARY KEY,
  date TEXT NOT NULL,
  camion_id BIGINT REFERENCES camions(id) ON DELETE SET NULL,
  camion_plaque TEXT DEFAULT '',
  chauffeur TEXT DEFAULT '',
  station TEXT DEFAULT '',
  qte NUMERIC DEFAULT 0,
  prix_unitaire NUMERIC DEFAULT 0,
  total NUMERIC DEFAULT 0,
  bon TEXT DEFAULT '',
  km NUMERIC,
  note TEXT DEFAULT '',
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABLE PAIEMENTS
CREATE TABLE IF NOT EXISTS paiements (
  id BIGSERIAL PRIMARY KEY,
  date TEXT NOT NULL,
  client_id BIGINT REFERENCES clients(id) ON DELETE SET NULL,
  client_nom TEXT DEFAULT '',
  mode TEXT DEFAULT '',
  montant NUMERIC DEFAULT 0,
  note TEXT DEFAULT '',
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECURITE RLS
-- ============================================================
ALTER TABLE clients       ENABLE ROW LEVEL SECURITY;
ALTER TABLE camions        ENABLE ROW LEVEL SECURITY;
ALTER TABLE fournisseurs   ENABLE ROW LEVEL SECURITY;
ALTER TABLE type_briques   ENABLE ROW LEVEL SECURITY;
ALTER TABLE ventes         ENABLE ROW LEVEL SECURITY;
ALTER TABLE gasoil         ENABLE ROW LEVEL SECURITY;
ALTER TABLE paiements      ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "own_clients"      ON clients      FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_camions"      ON camions       FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_fournisseurs" ON fournisseurs  FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_type_briques" ON type_briques  FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_ventes"       ON ventes        FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_gasoil"       ON gasoil        FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "own_paiements"    ON paiements     FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- DONNEES PAR DEFAUT (optionnel)
-- Apres votre premiere connexion, allez dans:
-- Supabase → Authentication → Users → copiez votre UUID
-- Remplacez 'VOTRE-UUID' par votre vrai UUID
-- ============================================================

/*
-- Fournisseurs par defaut
INSERT INTO fournisseurs (nom, user_id) VALUES
('NOVA BRIQ SARL', 'VOTRE-UUID'),
('DURA BRIQ',      'VOTRE-UUID'),
('SALIMO BRIQ',    'VOTRE-UUID');

-- Types de briques par defaut
INSERT INTO type_briques (nom, user_id) VALUES
('B12',    'VOTRE-UUID'),
('B10',    'VOTRE-UUID'),
('B7GF1',  'VOTRE-UUID'),
('B7GF2',  'VOTRE-UUID'),
('B05/03', 'VOTRE-UUID'),
('B06/07', 'VOTRE-UUID');

-- Clients par defaut
INSERT INTO clients (nom, depot, solde, user_id) VALUES
('Ahmed Beramdan El Rafei', 'BERKANE',  610549, 'VOTRE-UUID'),
('Soufian El Hajeb',        'EL HAJEB', 123880, 'VOTRE-UUID'),
('Tahiri Berkane',          'BERKANE',  111175, 'VOTRE-UUID'),
('Nouredine El Hajeb',      'EL HAJEB', 104440, 'VOTRE-UUID'),
('Abdeljalil',              'EL HAJEB',  40000, 'VOTRE-UUID'),
('Laghrisi El Hajeb',       'EL HAJEB',  36600, 'VOTRE-UUID'),
('El Mazrouai',             'BERKANE',   35850, 'VOTRE-UUID'),
('Tarek El Hajeb',          'EL HAJEB',  28700, 'VOTRE-UUID'),
('Youssef Haqqoun',         'EL HAJEB',  28450, 'VOTRE-UUID'),
('Hamid Khouti',            'EL HAJEB',  25509, 'VOTRE-UUID'),
('Mohamed Elaamrani',       'EL HAJEB',  10950, 'VOTRE-UUID'),
('Abdenbi El Hajeb',        'EL HAJEB',      0, 'VOTRE-UUID'),
('Abdelhamid Ahfir',        'AHFIR',         0, 'VOTRE-UUID'),
('Abdelhafid Berkane',      'BERKANE',       0, 'VOTRE-UUID'),
('Hicham Berkane',          'BERKANE',       0, 'VOTRE-UUID'),
('Said Taouima',            'TAOUIMA',       0, 'VOTRE-UUID');

-- Camions par defaut
INSERT INTO camions (plaque, depot, gasoil_dhs, pleins, litres, user_id) VALUES
('20181-B-50', 'EL HAJEB', 553255, 126, 50280, 'VOTRE-UUID'),
('23400-B-50', 'EL HAJEB', 407954, 186, 37082, 'VOTRE-UUID'),
('25188-B-50', 'EL HAJEB', 371728,  86, 33398, 'VOTRE-UUID'),
('21410-B-50', 'EL HAJEB', 355887, 147, 32503, 'VOTRE-UUID'),
('26892-B-50', 'EL HAJEB', 313276, 103, 28506, 'VOTRE-UUID'),
('19231-B-26', 'EL HAJEB', 311543, 130, 27796, 'VOTRE-UUID'),
('14489-B-26', 'EL HAJEB', 293689,  93, 26423, 'VOTRE-UUID'),
('53838-A-50', 'BERKANE',  257116, 143, 23001, 'VOTRE-UUID'),
('22504-B-50', 'EL HAJEB', 231475, 163, 20657, 'VOTRE-UUID'),
('19940-B-50', 'EL HAJEB',      0,   0,     0, 'VOTRE-UUID'),
('20562-B-50', 'EL HAJEB',      0,   0,     0, 'VOTRE-UUID'),
('13204-B-40', 'EL HAJEB',      0,   0,     0, 'VOTRE-UUID');
*/
